<?php 
	echo "<h2> Custom error</h2>";
	echo $msg;


?>