<?php 
	
	class index
	{
		public function getAlllist(){
			$dbcon = Database::getDb();
			$sql = "SELECT * FROM cds";
			
			$pdostm = $dbcon->prepare($sql); 
			$pdostm->execute();
			$cdss = $pdostm->fetchAll(PDO::FETCH_OBJ);
			return $cdss;
		}
		public function addlist($titel, $interpret, $jahr, $id){
			$db = Database::getDb();
			$sql = "INSERT INTO cds (titel, interpret, jahr, id)
				values(:cc, :preet, :mobile, :dev, :1)";
				
			$pst = $db->prepare($sql);
			$pst->bindParam(':preet',$titel);
			$pst->bindParam(':mobile',$interpret);
			$pst->bindParam(':dev',$jahr);
			$pst->bindParam(':1',$id);
			
			$count= $pst->execute();
			echo $count;
		}
	}
?>