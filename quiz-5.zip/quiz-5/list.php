<?php
	require_once 'Database.php';
	require_once 'index.php';
	
	$dbcon = Database::getDb();
	$cd = new index();
	$mylist = $cd->getalllist(Database::getDb());
	
	
	foreach($mylist as $Index){
		echo "<li>".$Index->titel ."</li>";
	}
	
	?>
	